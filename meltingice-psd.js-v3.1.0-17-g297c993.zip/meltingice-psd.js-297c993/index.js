require('coffee-script/register');
module.exports = require('./lib/psd.coffee');